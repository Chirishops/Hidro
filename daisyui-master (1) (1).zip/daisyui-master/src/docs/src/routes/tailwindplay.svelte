<script context="module">
  export async function load() {
    return {
      status: 302,
      redirect: "https://play.tailwindcss.com/gTlq3iys55",
    }
  }
</script>

<script>
  import { onMount } from "svelte"
  onMount(() => {
    window.location.href = "https://play.tailwindcss.com/gTlq3iys55"
  })
</script>
