<div class="hero not-prose min-h-screen">
  <div class="hero-content text-center">
    <div class="max-w-md">
      <h1 class="mb-5 text-5xl font-bold opacity-10 lg:text-7xl xl:text-9xl">404</h1>
      <p class="mb-5">Page not found</p>
      <a class="btn" href="/">Go back</a>
    </div>
  </div>
</div>
