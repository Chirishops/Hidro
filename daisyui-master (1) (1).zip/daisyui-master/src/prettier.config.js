module.exports = {
  semi: false,
  useTabs: false,
  tabWidth: 2,
  singleQuote: false,
  printWidth: 99999,
  htmlWhitespaceSensitivity: "ignore",
  trailingComma: "es5",
}
