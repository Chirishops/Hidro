module.exports = {
  content: ['index.html'],
  css: ['node_modules/bootstrap/dist/css/bootstrap.min.css'],
  output: './',
}