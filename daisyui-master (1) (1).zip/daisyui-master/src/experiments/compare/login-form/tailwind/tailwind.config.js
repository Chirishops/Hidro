module.exports = {
  content: ['./*.html'],
  darkMode: 'class',
}
