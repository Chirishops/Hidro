
module.exports = {
  plugins: {
    tailwindcss: {},
  },
};
