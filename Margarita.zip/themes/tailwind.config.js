module.exports = {
  content: [
    { raw: '' },
  ],
  corePlugins: {
    preflight: false,
  },
  daisyui: {
    base: false,
  },
  plugins: [require("../index")],
};
